<?php
	include 'inc/config.php'; 
	if (isset($_POST['deny'])){
		$denyid = $_POST['denyid'];
		$sql = "UPDATE leaves SET status = -1 WHERE id = $denyid";
		$run = mysqli_query($con, $sql);
		if($run == true){
			echo "<script> 
					alert('Application Disapproved');
					window.open('dashboard.php','_self');
				  </script>";
		} else {
			echo "<script> 
					alert('Failed To Disapprove');
				  </script>";
		}
	}
?>

